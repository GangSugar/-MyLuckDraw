package org.example.service;

import org.example.exception.AppException;
import org.example.mapper.SettingMapper;
import org.example.mapper.UserMapper;
import org.example.model.Setting;
import org.example.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

@Service
public class UserService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private SettingMapper settingMapper;

    private static final DateFormat DF = new SimpleDateFormat("yyyymmdd");//时间戳

    @Value("${user.head.local-path}")//取application.properties中设置的路径
    private String headLocalPath;

    @Value("${user.head.remote-path}")
    private String headRemotePath;

    public String saveHead(MultipartFile headFile) {
        //文件为当天，但是文件路径的间隔符和操作系统相关，可以使用File.separator  但是java一会根据操作系统自动生成
        Date now = new Date();
        //url是自己定义的，可以拼接的方式，也可以是时间戳的方式
        String dirurl = "/"+DF.format(now);//时间戳的路径，也就是生成文件夹加的目录
        File dir = new File(headLocalPath+dirurl);//文件夹的uri，也就是名称
        if (!dir.exists()) dir.mkdirs();//如果目录不存在，就生成这个目录
        String suffix = headFile.getOriginalFilename().substring(headFile.getOriginalFilename().lastIndexOf("."));
        //保存在本地以天为单位的文件夹，保证文件唯一：采用随机字符串作为文件名，但是后缀还需要保留
        String headName = UUID.randomUUID().toString()+suffix;//是整个文件名
        String url = dirurl+"/"+headName;
        try {
            headFile.transferTo(new File(headLocalPath+url));//保存在本地
        } catch (IOException e) {
            throw new AppException("REG001","四川文件头像出错");
        }

        return headRemotePath+url;//返回的是绝对路径
    }
//注册的业务逻辑
    //事务处理
    //内部实现aop，方法前加入开启事务逻辑，方法执行后，抛异常roolback，没有异常
    //禁止使用try catch进行吃异常操作
    @Transactional//这个注解是隔离事务，多个更新操作，防止一个改变了，但是另外一个不知道，导致结果出现问题
    public void register(User user) {
        //数据库校验，用户名不能重复
        //1.插入user数据
        int n = userMapper.insertSelective(user);//这里不需要插入id，但是插入之后，数据库自动生成了低

        //2.插入setting数据，因为登录后，进入设置页面，添加奖项和抽奖人员，需要setting_id
        Setting setting = new Setting();
        setting.setUserId(user.getId());
        setting.setBatchNumber(8);//设置抽奖人数，设置为默认值，这些都是固定的(有些业务逻辑都是有默认值的)
        int m = settingMapper.insertSelective(setting);//插入进去
    }

    public User queryByUsername(String username) {
        return userMapper.selectByUsername(username);
    }
}
