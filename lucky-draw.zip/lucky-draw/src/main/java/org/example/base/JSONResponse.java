package org.example.base;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 和前端统一好数据交互的形式
 */
@Getter
@Setter
@ToString
public class JSONResponse {
    private boolean success;//是否成功
    private String code;//错误码信息
    private String message;//错误信息
    private Object data;//成功需要返回给前端的数据格式
}
