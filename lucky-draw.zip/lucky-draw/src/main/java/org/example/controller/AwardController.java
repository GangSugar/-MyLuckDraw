package org.example.controller;

import org.example.model.Award;
import org.example.model.User;
import org.example.service.AwardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("/award")
public class AwardController {
    @Autowired
    private AwardService awardService;


    //新增奖项
    @RequestMapping("/add")
    public Object add(@RequestBody Award award, HttpSession session){
        User user = (User)session.getAttribute("user");
        //通过用户id查询setting_id
        int n = awardService.add(award,user.getId());
        return award.getId();//插入后返回给前端自增主键
        //return null;
    }
//修改
    @RequestMapping("/update")
    public Object update(@RequestBody Award award){
        int n = awardService.update(award);
        return null;
    }
    //删除
    @RequestMapping("/delete/{id}")
    public Object delete(@PathVariable Integer id){
        int n = awardService.delete(id);
        return null;
    }
}
