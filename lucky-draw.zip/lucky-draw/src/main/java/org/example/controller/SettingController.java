package org.example.controller;

import org.example.model.Award;
import org.example.model.Member;
import org.example.model.Setting;
import org.example.model.User;
import org.example.service.AwardService;
import org.example.service.MemberService;
import org.example.service.SettingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping("/setting")
public class SettingController {
    @Autowired
    private SettingService settingService;
    @Autowired
    private AwardService awardService;
    @Autowired
    private MemberService memberService;
    //进行抽奖设置页面，初始化接口，返回页面所有需要的数据
    //setting对象中的属性
    //setting中目前没有的属性：(1)user(用户信息)，(2)awards（奖项列表，根据setting_id查询）
    //(3)members(抽奖人员列表，根据setting_id查询)
    @RequestMapping("/query")
    public Object query(HttpSession session){
        //1.获取session中的user
        User user = (User)session.getAttribute("user");
        //2.根据userid查询setting信息
        Setting setting = settingService.queryByUserId(user.getId());
        //3.把user设置到setting新增属性user中
        setting.setUser(user);
        //4.根据setting_id查询award列表，设置到setting新增属性awards；
        List<Award> awards = awardService.queryBySettingId(setting.getId());
        setting.setAwards(awards);
        //4.根据setting_id查询member列表，设置到setting新增属性members；
        List<Member> members = memberService.queryBySettingId(setting.getId());
        setting.setMembers(members);
        return setting;
    }
//修改抽奖人数
    @RequestMapping("/update")
    public Object update(Integer batchNumber,HttpSession session){
        User user = (User)session.getAttribute("user");
        int n = settingService.update(batchNumber,user.getId());
        return null;
    }

}
