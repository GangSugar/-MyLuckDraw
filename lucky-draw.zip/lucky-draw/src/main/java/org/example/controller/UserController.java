package org.example.controller;

import org.example.exception.AppException;
import org.example.model.User;
import org.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    //用户注册
    @RequestMapping("/register")
    private Object register(User user, MultipartFile headFile){
        //一般有一个校验请求数据(后端必须有)，这里就省略了，因为前端已经检验过了
        //1.保存上传的用户头像到服务端本地
        String head = "";
        if (headFile != null) {
             head = userService.saveHead(headFile);//保存头像的方法,会得到一个头像保存在本地绝对路径
        }
        //2.上传的映射路径为http服务

        //3.用户头像的http路径设置到user，head，把user插入到数据库
        user.setHead(head);
        userService.register(user);//往数据库注册用户

        return null;
    }
    //登录操作
    @RequestMapping("/login")
    private Object login(@RequestBody User user, HttpServletRequest req){
        User exist = userService.queryByUsername(user.getUsername());
        //用户不存在
        if (exist == null){
            throw new AppException("LOG001","用户不存在");
        }
        //用户存在，校验密码
        if (!user.getPassword().equals(exist.getPassword())){
            throw new AppException("LOG002","账号或者密码错误");
        }
        //校验通过，保存数据库消息到session
        HttpSession session = req.getSession();//先创建session，默认传的是true，有session就直接获取到结果，没有就会自动创建一个session
        session.setAttribute("user",exist);
        return null;//登录成功，是因为在RequestResponseBodyMethodProcessorWrapper这个类里面已经包装好json数据了
    }

    //注销操作
    @RequestMapping("logout")
    public Object logout(HttpSession session){
        //删除掉session
        session.removeAttribute("user");
        return null;
    }
}

